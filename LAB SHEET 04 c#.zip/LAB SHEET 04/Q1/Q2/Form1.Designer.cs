﻿namespace Q2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Fnumber = new System.Windows.Forms.Label();
            this.txtFnumber = new System.Windows.Forms.TextBox();
            this.Snumber = new System.Windows.Forms.Label();
            this.txtSnumber = new System.Windows.Forms.TextBox();
            this.btnaddition = new System.Windows.Forms.Button();
            this.btnsubstraction = new System.Windows.Forms.Button();
            this.btnMultiplication = new System.Windows.Forms.Button();
            this.btnDivision = new System.Windows.Forms.Button();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Fnumber
            // 
            this.Fnumber.AutoSize = true;
            this.Fnumber.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fnumber.Location = new System.Drawing.Point(82, 75);
            this.Fnumber.Name = "Fnumber";
            this.Fnumber.Size = new System.Drawing.Size(227, 31);
            this.Fnumber.TabIndex = 2;
            this.Fnumber.Text = "Enter first number";
            // 
            // txtFnumber
            // 
            this.txtFnumber.Location = new System.Drawing.Point(368, 76);
            this.txtFnumber.Multiline = true;
            this.txtFnumber.Name = "txtFnumber";
            this.txtFnumber.Size = new System.Drawing.Size(264, 30);
            this.txtFnumber.TabIndex = 3;
            // 
            // Snumber
            // 
            this.Snumber.AutoSize = true;
            this.Snumber.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Snumber.Location = new System.Drawing.Point(82, 162);
            this.Snumber.Name = "Snumber";
            this.Snumber.Size = new System.Drawing.Size(261, 31);
            this.Snumber.TabIndex = 4;
            this.Snumber.Text = "Enter second number";
            // 
            // txtSnumber
            // 
            this.txtSnumber.Location = new System.Drawing.Point(368, 162);
            this.txtSnumber.Multiline = true;
            this.txtSnumber.Name = "txtSnumber";
            this.txtSnumber.Size = new System.Drawing.Size(264, 30);
            this.txtSnumber.TabIndex = 5;
            // 
            // btnaddition
            // 
            this.btnaddition.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddition.Location = new System.Drawing.Point(112, 253);
            this.btnaddition.Name = "btnaddition";
            this.btnaddition.Size = new System.Drawing.Size(96, 47);
            this.btnaddition.TabIndex = 6;
            this.btnaddition.Text = "+";
            this.btnaddition.UseVisualStyleBackColor = true;
            this.btnaddition.Click += new System.EventHandler(this.btnaddition_Click);
            // 
            // btnsubstraction
            // 
            this.btnsubstraction.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubstraction.Location = new System.Drawing.Point(262, 253);
            this.btnsubstraction.Name = "btnsubstraction";
            this.btnsubstraction.Size = new System.Drawing.Size(96, 47);
            this.btnsubstraction.TabIndex = 7;
            this.btnsubstraction.Text = "-";
            this.btnsubstraction.UseVisualStyleBackColor = true;
            this.btnsubstraction.Click += new System.EventHandler(this.btnsubstraction_Click);
            // 
            // btnMultiplication
            // 
            this.btnMultiplication.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultiplication.Location = new System.Drawing.Point(398, 253);
            this.btnMultiplication.Name = "btnMultiplication";
            this.btnMultiplication.Size = new System.Drawing.Size(96, 47);
            this.btnMultiplication.TabIndex = 8;
            this.btnMultiplication.Text = "x";
            this.btnMultiplication.UseVisualStyleBackColor = true;
            this.btnMultiplication.Click += new System.EventHandler(this.btnMultiplication_Click);
            // 
            // btnDivision
            // 
            this.btnDivision.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivision.Location = new System.Drawing.Point(536, 253);
            this.btnDivision.Name = "btnDivision";
            this.btnDivision.Size = new System.Drawing.Size(96, 47);
            this.btnDivision.TabIndex = 9;
            this.btnDivision.Text = "/";
            this.btnDivision.UseVisualStyleBackColor = true;
            this.btnDivision.Click += new System.EventHandler(this.btnDivision_Click);
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.Location = new System.Drawing.Point(343, 353);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(0, 31);
            this.lblAnswer.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.btnDivision);
            this.Controls.Add(this.btnMultiplication);
            this.Controls.Add(this.btnsubstraction);
            this.Controls.Add(this.btnaddition);
            this.Controls.Add(this.txtSnumber);
            this.Controls.Add(this.Snumber);
            this.Controls.Add(this.txtFnumber);
            this.Controls.Add(this.Fnumber);
            this.Name = "Form1";
            this.Text = "Q2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Fnumber;
        private System.Windows.Forms.TextBox txtFnumber;
        private System.Windows.Forms.Label Snumber;
        private System.Windows.Forms.TextBox txtSnumber;
        private System.Windows.Forms.Button btnaddition;
        private System.Windows.Forms.Button btnsubstraction;
        private System.Windows.Forms.Button btnMultiplication;
        private System.Windows.Forms.Button btnDivision;
        private System.Windows.Forms.Label lblAnswer;
    }
}

