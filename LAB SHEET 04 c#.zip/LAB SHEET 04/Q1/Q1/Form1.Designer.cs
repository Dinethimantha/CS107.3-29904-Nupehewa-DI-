﻿namespace Q1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnaddition = new System.Windows.Forms.Button();
            this.Fnumber = new System.Windows.Forms.Label();
            this.txtFnumber = new System.Windows.Forms.TextBox();
            this.Snumber = new System.Windows.Forms.Label();
            this.txtSnumber = new System.Windows.Forms.TextBox();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnaddition
            // 
            this.btnaddition.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddition.Location = new System.Drawing.Point(202, 242);
            this.btnaddition.Name = "btnaddition";
            this.btnaddition.Size = new System.Drawing.Size(337, 50);
            this.btnaddition.TabIndex = 0;
            this.btnaddition.Text = "Calculate Addition";
            this.btnaddition.UseVisualStyleBackColor = true;
            this.btnaddition.Click += new System.EventHandler(this.btnaddition_Click);
            // 
            // Fnumber
            // 
            this.Fnumber.AutoSize = true;
            this.Fnumber.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fnumber.Location = new System.Drawing.Point(70, 52);
            this.Fnumber.Name = "Fnumber";
            this.Fnumber.Size = new System.Drawing.Size(227, 31);
            this.Fnumber.TabIndex = 1;
            this.Fnumber.Text = "Enter first number";
            // 
            // txtFnumber
            // 
            this.txtFnumber.Location = new System.Drawing.Point(384, 53);
            this.txtFnumber.Multiline = true;
            this.txtFnumber.Name = "txtFnumber";
            this.txtFnumber.Size = new System.Drawing.Size(264, 30);
            this.txtFnumber.TabIndex = 2;
            // 
            // Snumber
            // 
            this.Snumber.AutoSize = true;
            this.Snumber.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Snumber.Location = new System.Drawing.Point(70, 140);
            this.Snumber.Name = "Snumber";
            this.Snumber.Size = new System.Drawing.Size(261, 31);
            this.Snumber.TabIndex = 3;
            this.Snumber.Text = "Enter second number";
            // 
            // txtSnumber
            // 
            this.txtSnumber.Location = new System.Drawing.Point(384, 141);
            this.txtSnumber.Multiline = true;
            this.txtSnumber.Name = "txtSnumber";
            this.txtSnumber.Size = new System.Drawing.Size(264, 30);
            this.txtSnumber.TabIndex = 4;
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.Location = new System.Drawing.Point(347, 339);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(0, 31);
            this.lblAnswer.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.txtSnumber);
            this.Controls.Add(this.Snumber);
            this.Controls.Add(this.txtFnumber);
            this.Controls.Add(this.Fnumber);
            this.Controls.Add(this.btnaddition);
            this.Name = "Form1";
            this.Text = "Q1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnaddition;
        private System.Windows.Forms.Label Fnumber;
        private System.Windows.Forms.TextBox txtFnumber;
        private System.Windows.Forms.Label Snumber;
        private System.Windows.Forms.TextBox txtSnumber;
        private System.Windows.Forms.Label lblAnswer;
    }
}

