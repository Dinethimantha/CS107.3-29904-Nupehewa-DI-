﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{ 
        class Book
        {
        public string Title;
        public string Author;
        }

        class Program
        {
            static void Main(string[] args)
            {
               
                Book myBook = new Book();

               
                myBook.Title = "THE PRINCE AND THE PAUPER";
                myBook.Author = "Mark Twain";

               
                Console.WriteLine("Book Title: " + myBook.Title);
                Console.WriteLine("Author: " + myBook.Author);

                Console.ReadLine(); 
            }
        }

    }

