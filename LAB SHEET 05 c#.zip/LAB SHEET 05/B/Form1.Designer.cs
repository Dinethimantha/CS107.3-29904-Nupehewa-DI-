﻿namespace B
{
    partial class SIGNUP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblsignup = new System.Windows.Forms.Label();
            this.lblfname = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lbllname = new System.Windows.Forms.Label();
            this.lblconpassword = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.txtconpassword = new System.Windows.Forms.TextBox();
            this.txtlname = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnsignup = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblsignup
            // 
            this.lblsignup.AutoSize = true;
            this.lblsignup.BackColor = System.Drawing.Color.Transparent;
            this.lblsignup.Font = new System.Drawing.Font("Stencil", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsignup.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblsignup.Location = new System.Drawing.Point(401, 48);
            this.lblsignup.Name = "lblsignup";
            this.lblsignup.Size = new System.Drawing.Size(352, 56);
            this.lblsignup.TabIndex = 3;
            this.lblsignup.Text = "SIGN UP HERE";
            this.lblsignup.Click += new System.EventHandler(this.lblsignup_Click);
            // 
            // lblfname
            // 
            this.lblfname.AutoSize = true;
            this.lblfname.BackColor = System.Drawing.Color.Transparent;
            this.lblfname.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfname.ForeColor = System.Drawing.Color.White;
            this.lblfname.Location = new System.Drawing.Point(237, 154);
            this.lblfname.Name = "lblfname";
            this.lblfname.Size = new System.Drawing.Size(141, 31);
            this.lblfname.TabIndex = 4;
            this.lblfname.Text = "First Name";
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.BackColor = System.Drawing.Color.Transparent;
            this.lblusername.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.Color.White;
            this.lblusername.Location = new System.Drawing.Point(237, 390);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(130, 31);
            this.lblusername.TabIndex = 5;
            this.lblusername.Text = "Username";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.BackColor = System.Drawing.Color.Transparent;
            this.lblemail.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.ForeColor = System.Drawing.Color.White;
            this.lblemail.Location = new System.Drawing.Point(237, 325);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(77, 31);
            this.lblemail.TabIndex = 6;
            this.lblemail.Text = "Email";
            this.lblemail.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.BackColor = System.Drawing.Color.Transparent;
            this.lbldob.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldob.ForeColor = System.Drawing.Color.White;
            this.lbldob.Location = new System.Drawing.Point(237, 269);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(164, 31);
            this.lbldob.TabIndex = 7;
            this.lbldob.Text = "Date of Birth";
            this.lbldob.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbllname
            // 
            this.lbllname.AutoSize = true;
            this.lbllname.BackColor = System.Drawing.Color.Transparent;
            this.lbllname.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllname.ForeColor = System.Drawing.Color.White;
            this.lbllname.Location = new System.Drawing.Point(237, 210);
            this.lbllname.Name = "lbllname";
            this.lbllname.Size = new System.Drawing.Size(137, 31);
            this.lbllname.TabIndex = 8;
            this.lbllname.Text = "Last Name";
            // 
            // lblconpassword
            // 
            this.lblconpassword.AutoSize = true;
            this.lblconpassword.BackColor = System.Drawing.Color.Transparent;
            this.lblconpassword.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconpassword.ForeColor = System.Drawing.Color.White;
            this.lblconpassword.Location = new System.Drawing.Point(237, 525);
            this.lblconpassword.Name = "lblconpassword";
            this.lblconpassword.Size = new System.Drawing.Size(225, 31);
            this.lblconpassword.TabIndex = 9;
            this.lblconpassword.Text = "Confirm Password";
            this.lblconpassword.Click += new System.EventHandler(this.lblconpassword_Click);
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.BackColor = System.Drawing.Color.Transparent;
            this.lblpassword.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.ForeColor = System.Drawing.Color.White;
            this.lblpassword.Location = new System.Drawing.Point(237, 460);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(124, 31);
            this.lblpassword.TabIndex = 10;
            this.lblpassword.Text = "Password";
            // 
            // txtfname
            // 
            this.txtfname.BackColor = System.Drawing.Color.Gainsboro;
            this.txtfname.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfname.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtfname.Location = new System.Drawing.Point(490, 148);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(433, 37);
            this.txtfname.TabIndex = 11;
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.Gainsboro;
            this.txtemail.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtemail.Location = new System.Drawing.Point(490, 323);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(433, 37);
            this.txtemail.TabIndex = 12;
            // 
            // txtpassword
            // 
            this.txtpassword.BackColor = System.Drawing.Color.Gainsboro;
            this.txtpassword.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtpassword.Location = new System.Drawing.Point(490, 460);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(433, 37);
            this.txtpassword.TabIndex = 13;
            // 
            // txtusername
            // 
            this.txtusername.BackColor = System.Drawing.Color.Gainsboro;
            this.txtusername.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtusername.Location = new System.Drawing.Point(490, 390);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(433, 37);
            this.txtusername.TabIndex = 14;
            // 
            // txtconpassword
            // 
            this.txtconpassword.BackColor = System.Drawing.Color.Gainsboro;
            this.txtconpassword.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtconpassword.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtconpassword.Location = new System.Drawing.Point(490, 519);
            this.txtconpassword.Name = "txtconpassword";
            this.txtconpassword.Size = new System.Drawing.Size(433, 37);
            this.txtconpassword.TabIndex = 15;
            // 
            // txtlname
            // 
            this.txtlname.BackColor = System.Drawing.Color.Gainsboro;
            this.txtlname.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlname.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtlname.Location = new System.Drawing.Point(490, 208);
            this.txtlname.Name = "txtlname";
            this.txtlname.Size = new System.Drawing.Size(433, 37);
            this.txtlname.TabIndex = 16;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(490, 269);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(433, 33);
            this.dateTimePicker1.TabIndex = 17;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(252, 600);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(183, 29);
            this.checkBox1.TabIndex = 18;
            this.checkBox1.Text = "I\'m not a robbot";
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // btnsignup
            // 
            this.btnsignup.BackColor = System.Drawing.Color.Silver;
            this.btnsignup.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsignup.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsignup.Location = new System.Drawing.Point(607, 673);
            this.btnsignup.Name = "btnsignup";
            this.btnsignup.Size = new System.Drawing.Size(183, 50);
            this.btnsignup.TabIndex = 19;
            this.btnsignup.Text = "SIGN UP";
            this.btnsignup.UseVisualStyleBackColor = false;
            this.btnsignup.Click += new System.EventHandler(this.btnsignup_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.Silver;
            this.btnReset.Font = new System.Drawing.Font("Stencil", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(288, 673);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(113, 34);
            this.btnReset.TabIndex = 20;
            this.btnReset.Text = "RESET";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // SIGNUP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::B.Properties.Resources._2be631e3afc5ba303f6315ba8d4c41f3;
            this.ClientSize = new System.Drawing.Size(1173, 754);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnsignup);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.txtlname);
            this.Controls.Add(this.txtconpassword);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtfname);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.lblconpassword);
            this.Controls.Add(this.lbllname);
            this.Controls.Add(this.lbldob);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.lblfname);
            this.Controls.Add(this.lblsignup);
            this.Name = "SIGNUP";
            this.Text = "SIGN UP";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblsignup;
        private System.Windows.Forms.Label lblfname;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lbllname;
        private System.Windows.Forms.Label lblconpassword;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.TextBox txtconpassword;
        private System.Windows.Forms.TextBox txtlname;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btnsignup;
        private System.Windows.Forms.Button btnReset;
    }
}

