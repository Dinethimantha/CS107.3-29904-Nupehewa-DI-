﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B
{
    public partial class USER : Form
    {
        public USER(string firstName, string username, string email)
        {
            InitializeComponent();


            lblfname.Text = $"First Name: {firstName}";
            lblusername.Text = $"Username: {username}";
            lblemail.Text = $"Email: {email}";
        }
    }
}
