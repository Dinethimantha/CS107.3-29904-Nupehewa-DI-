﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B
{
    public partial class SIGNUP : Form
    {
        public SIGNUP()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void lblconpassword_Click(object sender, EventArgs e)
        {

        }

        private void lblsignup_Click(object sender, EventArgs e)
        {

        }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            string FirstName = txtfname.Text;
            string LastName = txtlname.Text;
            string DOB = dateTimePicker1.Value.ToShortDateString();
            string Email = txtemail.Text;
            string Username = txtusername.Text;
            string Password = txtpassword.Text;
            string ConfirmPassword = txtconpassword.Text;
            bool Imnotarobbot = checkBox1.Checked;

            if (!string.IsNullOrWhiteSpace(FirstName) &&
                !string.IsNullOrWhiteSpace(LastName) &&
                !string.IsNullOrWhiteSpace(DOB) &&
                !string.IsNullOrWhiteSpace(Email) &&
                !string.IsNullOrWhiteSpace(Username) &&
                !string.IsNullOrWhiteSpace(Password) &&
                !string.IsNullOrWhiteSpace(ConfirmPassword) &&
                Password == ConfirmPassword &&
                Imnotarobbot)
            {
                if (AreAllFieldsStrings())
                {

                    var userInterface = new USER(FirstName, Username, Email);
                    userInterface.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("All fields should be strings.");
                }
            }
            else
            {
                MessageBox.Show("All fields are required and passwords must match.");
            }
        }
        private bool AreAllFieldsStrings()
        {

            return true;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtfname.Clear();
            txtlname.Clear();
            dateTimePicker1.Value = DateTime.Today;
            txtemail.Clear();
            txtusername.Clear();
            txtpassword.Clear();
            txtconpassword.Clear();
        }
    }
    }

